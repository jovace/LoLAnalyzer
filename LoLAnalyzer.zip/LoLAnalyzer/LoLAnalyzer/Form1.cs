﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoLAnalyzer
{
    public partial class Form1 : Form
    {
        GameData partida;
        long gameTime=0;

        public Form1()
        {
            InitializeComponent();
            GameData partida = new GameData();
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            int xCoord = e.Location.X;
            int yCoord = e.Location.Y;

            int playerId=-1;
            if (radioButton1.Checked) { playerId = 0; } //TOP BLUE
            if (radioButton2.Checked) { playerId = 1; } //JNG BLUE
            if (radioButton3.Checked) { playerId = 2; }
            if (radioButton4.Checked) { playerId = 3; }
            if (radioButton5.Checked) { playerId = 4; } //SUP BLUE
            if (radioButton6.Checked) { playerId = 5; } //TOP RED
            if (radioButton7.Checked) { playerId = 6; }
            if (radioButton8.Checked) { playerId = 7; }
            if (radioButton9.Checked) { playerId = 8; }
            if (radioButton10.Checked) { playerId = 9; } //SUP RED

            int wardType = -1;
            if (radioButton11.Checked) { wardType = 0; } //GREEN <9
            if (radioButton12.Checked) { wardType = 1; } //GREEN >9
            if (radioButton13.Checked) { wardType = 2; } //SS
            if (radioButton14.Checked) { wardType = 3; } //Pink
            if (radioButton15.Checked) { wardType = 4; } //Blue
            if (radioButton16.Checked) { wardType = 5; } //Lente

            partida.addWard(playerId, xCoord, yCoord, gameTime, wardType);
        }

        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            partida = new GameData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            gameTime += 100;
            textBox1.Text = (gameTime/1000).ToString();

            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < partida.listWards.Count; i++)
            {
                textBox2.Text += "{ \n 'playerId':" + partida.getWard(i).player + ",'posX':" + partida.getWard(i).posX
                                + ",'posY':" + partida.getWard(i).posY + ",'wardType':" + partida.getWard(i).wardType + ",'timeStamp':" + partida.getWard(i).timeStamp + "\n } \n \n";
            }
        }
    }

    [Serializable]
    class GameData 
    {
        public List<Ward> listWards = new List<Ward>();
             
        public GameData()
        {
            
            
        }

        public void addWard(int playerId, int posX, int posY, long timeStamp, int wardType)
        {
            listWards.Add(new Ward(playerId, posX, posY, timeStamp, wardType));
        }

        public Ward getWard(int index)
        {
            return listWards.ElementAt(index);
        }

    }

    class Ward
    {
        public int posX;
        public int posY;
        public long timeStamp;
        public int player;
        public int wardType;

        public Ward(int playerIda, int posXa, int posYa, long timeStampa, int wardTypea)
        {
            this.posX = posXa;
            this.posY = posYa;
            this.player = playerIda;
            this.timeStamp = timeStampa;
            this.wardType = wardTypea;
        }
    }
}
